/* **********     Curso JavaScript: 123. Ejercicios AJAX - APIs: Incluir archivos HTML (include-html.js) - #jonmircha     ********** */
