/* **********     Curso JavaScript: 93. DOM: Ejercicios Prácticos | Detección del estado de la red - #jonmircha     ********** */
